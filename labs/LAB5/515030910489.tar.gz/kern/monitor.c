// Simple command-line kernel monitor useful for
// controlling the kernel and exploring the system interactively.

#include <inc/stdio.h>
#include <inc/string.h>
#include <inc/memlayout.h>
#include <inc/assert.h>
#include <inc/x86.h>

#include <kern/console.h>
#include <kern/monitor.h>
#include <kern/kdebug.h>

#include <kern/trap.h>

#include <kern/pmap.h>
#include <kern/env.h>

#define CMDBUF_SIZE	80	// enough for one VGA text line

typedef unsigned long long __u64;
typedef unsigned int __u32;

struct Command {
	const char *name;
	const char *desc;
	// return -1 to force monitor to exit
	int (*func)(int argc, char** argv, struct Trapframe* tf);
};

static struct Command commands[] = {
	{ "help", "Display this list of commands", mon_help },
	{ "kerninfo", "Display information about the kernel", mon_kerninfo },
        { "backtrace", "Display information about backtrace", mon_backtrace },
        { "time", "Display information about time consumed", mon_time },
        { "showmappings", "Display information about phtsical page according to the input va", mon_showmappings },
        { "setpermissions", "set , clear or change permissons", mon_setpermissions },
        { "memdump", "dump the content of given memory range", mon_memdump },
        { "c","continue",mon_c},
        { "si","next step",mon_si},
        { "x","show memory",mon_x},
};
#define NCOMMANDS (sizeof(commands)/sizeof(commands[0]))

unsigned read_eip();

/***** Implementations of basic kernel monitor commands *****/

int
mon_help(int argc, char **argv, struct Trapframe *tf)
{
	int i;

	for (i = 0; i < NCOMMANDS; i++)
		cprintf("%s - %s\n", commands[i].name, commands[i].desc);
	return 0;
}

int
mon_kerninfo(int argc, char **argv, struct Trapframe *tf)
{
	extern char entry[], etext[], edata[], end[];

	cprintf("Special kernel symbols:\n");
	cprintf("  entry  %08x (virt)  %08x (phys)\n", entry, entry - KERNBASE);
	cprintf("  etext  %08x (virt)  %08x (phys)\n", etext, etext - KERNBASE);
	cprintf("  edata  %08x (virt)  %08x (phys)\n", edata, edata - KERNBASE);
	cprintf("  end    %08x (virt)  %08x (phys)\n", end, end - KERNBASE);
	cprintf("Kernel executable memory footprint: %dKB\n",
		(end-entry+1023)/1024);
	return 0;
}

// Lab1 only
// read the pointer to the retaddr on the stack
static uint32_t
read_pretaddr() {
    uint32_t pretaddr;
    __asm __volatile("leal 4(%%ebp), %0" : "=r" (pretaddr)); 
    return pretaddr;
}

int
mon_backtrace(int argc, char **argv, struct Trapframe *tf)
{
    
    cprintf("Stack backtrace\n");
    uint32_t *bp;
    uint32_t ip;
    struct Eipdebuginfo info;
    
    bp=(uint32_t *)read_ebp();
    
 

    while(bp!=0){

       ip = bp[1];
       //ebp = bp[0];
       
       debuginfo_eip(ip,&info);

       cprintf("eip %08x ebp %08x args %08x %08x %08x %08x %08x\n", ip, bp, bp[2], bp[3], bp[4], bp[5], bp[6]);
       
 
       cprintf("       %s:%d: %s+%d\n", 
                 info.eip_file, info.eip_line, 
                 info.eip_fn_name, info.eip_fn_namelen);

       bp = (uint32_t *)(*bp);
    }




	// Your code here.
    cprintf("Backtrace success\n");
	return 0;
}

__u64 rdtsc()
{
        __u32 lo,hi;

        __asm__ __volatile__
        (
         "rdtsc":"=a"(lo),"=d"(hi)
        );
        return (__u64)hi<<32|lo;
}

int
mon_time(int argc, char **argv, struct Trapframe *tf)
{
	 __u64 begin;
        __u64 end;
        
        if(argc != 2){
           cprintf("please foemat you instruction like \" time [command]\"");
           return 0;
        }
        argc--;
        if(strcmp(argv[1],"help")==0){
           begin = rdtsc();
           mon_help(argc, argv, tf);
           end = rdtsc();
           cprintf("myfunction cost %llu CPU cycles\n",end-begin);
           return 0;
        }
        else if(strcmp(argv[1],"kerninfo")==0){
           begin = rdtsc();
           mon_kerninfo(argc, argv, tf);
           end = rdtsc();
           cprintf("myfunction cost %llu CPU cycles\n",end-begin);
           return 0;
        }
        else if(strcmp(argv[1],"backtrace")==0){
           begin = rdtsc();
           mon_backtrace(argc, argv, tf);
           end = rdtsc();
           cprintf("myfunction cost %llu CPU cycles\n",end-begin);
           return 0;
        }

        return 0;

        
}

int
mon_showmappings(int argc, char **argv, struct Trapframe *tf)
{
        
        if(argc != 3){
           cprintf("please foemat you instruction like \" showmappings va va\"");
           return 0;
        }
        uintptr_t begin = strtol(argv[1],0,0);
        uintptr_t end = strtol(argv[2],0,0);
        pte_t *PTE;
        int i = begin;
        for(; i<=end ; i+=0x1000){
            PTE = pgdir_walk(kern_pgdir, (const void *)i, 0);
            if((PTE==NULL) || ((*PTE)&PTE_P) ==0) cprintf("None");
            cprintf("0x%08x -> 0x%08x ", i, PTE_ADDR(*PTE));
            if((*PTE)&PTE_W) cprintf("W ");
            if((*PTE)&PTE_U) cprintf("U ");
            if((*PTE)&PTE_PWT) cprintf("PWT ");
            if((*PTE)&PTE_PCD) cprintf("PCD ");
            if((*PTE)&PTE_A) cprintf("A ");
            if((*PTE)&PTE_D) cprintf("D ");
            if((*PTE)&PTE_PS) cprintf("PS ");
            if((*PTE)&PTE_G) cprintf("G ");
            cprintf("\n");
        }
        if(i!=end){
            PTE = pgdir_walk(kern_pgdir, (const void *)end, 0);
            if((PTE==NULL) || ((*PTE)&PTE_P) ==0) cprintf("None");
            cprintf("0x%08x -> 0x%08x ", i, PTE_ADDR(*PTE));
            if((*PTE)&PTE_W) cprintf("W ");
            if((*PTE)&PTE_U) cprintf("U ");
            if((*PTE)&PTE_PWT) cprintf("PWT ");
            if((*PTE)&PTE_PCD) cprintf("PCD ");
            if((*PTE)&PTE_A) cprintf("A ");
            if((*PTE)&PTE_D) cprintf("D ");
            if((*PTE)&PTE_PS) cprintf("PS ");
            if((*PTE)&PTE_G) cprintf("G ");
            cprintf("\n");
        }
 
        return 0;       
}


int
mon_setpermissions(int argc, char **argv, struct Trapframe *tf)
{
        
        if(argc != 4){
           cprintf("please foemat you instruction like \" setpermissions [perm] 0/1 va \"");
           return 0;
        }
        
        uintptr_t value = strtol(argv[2],0,0);
        uintptr_t va = strtol(argv[3],0,0);
        pte_t *PTE = pgdir_walk(kern_pgdir, (const void *)va, 0);
        if(value == 1){
           if(strcmp(argv[1],"PTE_P")==0){
              *PTE = *PTE | PTE_P;          
           }
           else if(strcmp(argv[1],"PTE_U")==0){
              *PTE = *PTE | PTE_U; 
           }
           else if(strcmp(argv[1],"PTE_W")==0){
              *PTE = *PTE | PTE_W; 
           }
           else if(strcmp(argv[1],"PTE_PWT")==0){
              *PTE = *PTE | PTE_PWT; 
           }
           else if(strcmp(argv[1],"PTE_PCD")==0){
              *PTE = *PTE | PTE_PCD; 
           }
           else if(strcmp(argv[1],"PTE_A")==0){
              *PTE = *PTE | PTE_A; 
           }
           else if(strcmp(argv[1],"PTE_D")==0){
              *PTE = *PTE | PTE_D; 
           }
           else if(strcmp(argv[1],"PTE_PS")==0){
              *PTE = *PTE | PTE_PS; 
           }
           else if(strcmp(argv[1],"PTE_G")==0){
              *PTE = *PTE | PTE_G; 
           }
        }
        else{
           if(strcmp(argv[1],"PTE_P")==0){
              *PTE = *PTE & ~PTE_P;          
           }
           else if(strcmp(argv[1],"PTE_U")==0){
              *PTE = *PTE & ~PTE_U; 
           }
           else if(strcmp(argv[1],"PTE_W")==0){
              *PTE = *PTE & ~PTE_W; 
           }
           else if(strcmp(argv[1],"PTE_PWT")==0){
              *PTE = *PTE & ~PTE_PWT; 
           }
           else if(strcmp(argv[1],"PTE_PCD")==0){
              *PTE = *PTE & ~PTE_PCD; 
           }
           else if(strcmp(argv[1],"PTE_A")==0){
              *PTE = *PTE & ~PTE_A; 
           }
           else if(strcmp(argv[1],"PTE_D")==0){
              *PTE = *PTE & ~PTE_D; 
           }
           else if(strcmp(argv[1],"PTE_PS")==0){
              *PTE = *PTE & ~PTE_PS; 
           }
           else if(strcmp(argv[1],"PTE_G")==0){
              *PTE = *PTE & ~PTE_G; 
           }
        }
        return 0;
           
}

int
mon_memdump(int argc, char **argv, struct Trapframe *tf)
{
        
        if(argc != 4){
           cprintf("please foemat you instruction like \" memdump p/v addr addr\"");
           return 0;
        }
        uintptr_t begin = strtol(argv[2],0,0);
        uintptr_t end = strtol(argv[3],0,0);
        int i = begin;
        if(strcmp(argv[1],"v")==0){
          for(;i<end; i++){
             if(i>0xffffffff) break;
             cprintf("%02x", *((char *)i));
          }
        }
        else if(strcmp(argv[1],"p")==0){
          for(;i<end; i++){
             if(i>0x0fffffff) {
                cprintf("END");
                break;
             }
             cprintf("%02x", *((char *)(i+KERNBASE)));
          }
        }
        cprintf("\n");
        return 0;       
}

int 
mon_x(int argc,char **argv,struct Trapframe *tf){
   if(argc != 2)
     cprintf("Usage: x [addr]\n");   
   else if(tf == NULL)
     cprintf("trapframe error\n");
   else{
       uint32_t addr = strtol(argv[1],0,0);
       uint32_t value = 0; 
       value = *((uint32_t*)addr);
       cprintf("%d\n",value);
    }
    return 0;
}

int 
mon_si(int argc,char **argv,struct Trapframe *tf){
  if(argc != 1)
    cprintf("Usage: si\n");
  else if(tf == NULL)
    cprintf("trapframe error\n");
  else{
    struct Eipdebuginfo info;
    tf->tf_eflags = tf->tf_eflags | 0x100;
    cprintf("tf_eip=%08x\n",tf->tf_eip);
    debuginfo_eip(tf->tf_eip,&info);
    cprintf("%s:%d: %s+%d\n",info.eip_file,info.eip_line,info.eip_fn_name,tf->tf_eip-info.eip_fn_addr);
    curenv->env_tf = *tf;		
    tf = &curenv->env_tf;
    env_run(curenv);
  }
  return 0;
}

int 
mon_c(int argc,char **argv,struct Trapframe *tf){
  
        uint32_t eflags;
	if (tf == NULL) {
		cprintf("No trapped environment\n");
		return 1;
	}
	eflags = tf->tf_eflags;
	eflags &= ~FL_TF;
	tf->tf_eflags = eflags;
	env_run(curenv);
	return 0;
} 




/***** Kernel monitor command interpreter *****/

#define WHITESPACE "\t\r\n "
#define MAXARGS 16

static int
runcmd(char *buf, struct Trapframe *tf)
{
	int argc;
	char *argv[MAXARGS];
	int i;

	// Parse the command buffer into whitespace-separated arguments
	argc = 0;
	argv[argc] = 0;
	while (1) {
		// gobble whitespace
		while (*buf && strchr(WHITESPACE, *buf))
			*buf++ = 0;
		if (*buf == 0)
			break;

		// save and scan past next arg
		if (argc == MAXARGS-1) {
			cprintf("Too many arguments (max %d)\n", MAXARGS);
			return 0;
		}
		argv[argc++] = buf;
		while (*buf && !strchr(WHITESPACE, *buf))
			buf++;
	}
	argv[argc] = 0;

	// Lookup and invoke the command
	if (argc == 0)
		return 0;
	for (i = 0; i < NCOMMANDS; i++) {
		if (strcmp(argv[0], commands[i].name) == 0)
			return commands[i].func(argc, argv, tf);
	}
	cprintf("Unknown command '%s'\n", argv[0]);
	return 0;
}

void
monitor(struct Trapframe *tf)
{
	char *buf;

	cprintf("Welcome to the JOS kernel monitor!\n");
	cprintf("Type 'help' for a list of commands.\n");

	if (tf != NULL)
		print_trapframe(tf);

	while (1) {
		buf = readline("K> ");
		if (buf != NULL)
			if (runcmd(buf, tf) < 0)
				break;
	}
}

// return EIP of caller.
// does not work if inlined.
// putting at the end of the file seems to prevent inlining.
unsigned
read_eip()
{
	uint32_t callerpc;
	__asm __volatile("movl 4(%%ebp), %0" : "=r" (callerpc));
	return callerpc;
}
